# Flow changelog

## v2.54.2 – Zrozumiteľné chyby pri prihlásení a rýchlejší zápis archívu

- Prihlasovacia obrazovka už neukazuje zavádzajúce „Backend ešte nemá prihlásenie“ pri každej chybe. Zobrazí skutočnú príčinu: chyba servera s textom, zaneprázdnený server, nepovolený účet, alebo odporúčanie skontrolovať nasadenie Apps Scriptu.
- Oprava možnej príčiny pádu prihlásenia: zápis archívu odhadov do Google Sheets robil dve volania na každý riadok, takže veľká požiadavka držala zámok scriptu minúty a blokovala ostatné (aj prihlásenie). Teraz sa zapisuje celý blok naraz (4 volania namiesto tisícov) a vyhodnotenie archívu ide v dávkach po 100 riadkoch.
- Apps Script v2.54.2: kódy chýb (server_error, busy, unknown_action) a diagnostický dotaz ?get=ping, ktorý vráti verziu backendu bez tokenu (nič z dát).

## v2.54.1 – Oprava nadhodnotených porovnaní minulých mesiacov

- Oprava: porovnania minulých mesiacov (plán a odhad) ukazovali približne šesťnásobok skutočnosti. Archív odhadov obsahoval viac kópií toho istého odhadu (z opakovaného prepočtu histórie) a appka ich sčítavala. Teraz sa berie jedna, najnovšia kópia.
- Už uložené chybné snímky sa nezobrazujú, pri štarte sa prepočítajú a opravia aj v cloude (vyžaduje Apps Script v2.54.1).
- Apps Script v2.54.1: nahradenie snímky staršej verzie novšou a funkcia reportForecastArchiveDuplicates (len na čítanie), ktorá vypíše počet duplicitných riadkov v archíve.

## v2.54.0 – Trvalé uloženie porovnania odhad vs. skutočnosť

- Porovnania za ukončené mesiace (odhad, plán, skutočnosť, rozdiel, celkovo aj po kategóriách) sa po skončení mesiaca uložia ako snímka a po refreshi už nezmiznú. Ukladajú sa lokálne aj do Google Sheets (nový hárok FlowMonthSnapshots), takže ich uvidíš aj na druhom zariadení.
- Uložená snímka ukončeného mesiaca sa už neprepočítava ani neprepisuje, zobrazuje sa vždy z uložených dát. Aktuálny mesiac sa počíta živo ako doteraz.
- Pri štarte sa uložené snímky načítajú ako prvé, chýbajúce ukončené mesiace sa dopočítajú a hneď uložia. Pri výpadku siete ostanú v telefóne a odošlú sa neskôr.
- Príčina zmiznutia: Google Sheets zmenil mesiac 2026-09 na dátum, ten sa vrátil ako časová značka a appka ho nespárovala. Mesiac sa teraz páruje správne aj z dátumu, nový Apps Script (v2.54.0) ho ukladá ako text.
- Vyžaduje nový Google Apps Script v2.54.0. Raz spusti funkciu repairForecastArchiveMonths, ktorá opraví už poškodený stĺpec s mesiacom v hárku FlowForecastArchive.

## v2.53.0 – Presnejšie odhady, reálna rezerva, testy

- Koľko ešte môžem minúť: rezerva sa počíta z rozpočtu, už minutých peňazí a pravidelných platieb, ktoré ešte prídu. Keď míňaš menej než zvyčajne, rezerva rastie (predtým ostávala stále rovnaká).
- Odhad výdavkov na koniec mesiaca zohľadňuje, ako rýchlo míňaš. Pod obvyklým tempom je nižší, nad ním vyšší. Pri odhade je orientačné rozpätie (typicky od – do).
- Oprava: karta Prehľad mesiaca sa prekreslí hneď po uložení transakcie aj po synchronizácii (predtým ostala stará, kým si neprepol obrazovku).
- Oprava výpočtu: nepozorovaný mesiac v rozbehnutom roku sa už nepočíta ako mesiac s nulovými výdavkami. Týka sa modelov legacy-adaptive, seasonal-index a multi-year-trend, odhady niektorých kategórií sa môžu zmeniť.
- Diagnostika forecastu: nové porovnanie šampiónov s jednoduchým modelom na tvojich dátach.
- Automatické testy výpočtov (node --test tests/unit/*.test.js).

## v2.52.1 – Kratšie obdobie pre Často používané

- Návrhy v riadku Často používané sa počítajú z posledných 30 dní (predtým 120), takže sa rýchlejšie prispôsobia tomu, čo práve zadávaš.

## v2.52.0 – Rýchle pridanie výdavku

- Pri novej transakcii pribudol riadok Často používané: kombinácie typ, kategória, podkategória a poznámka z posledných 120 dní (napr. Billa, Slovnaft, Výplata). Jedno klepnutie vyplní formulár, stačí napísať sumu a uložiť.
- Návrhy sa radia podľa počtu použití. Pravidelné platby, zmazané záznamy a historický import sa nezapočítavajú. Suma sa nikdy nepredvypĺňa.
- Skratky z ikony appky: dlhým podržaním ikony Flow na ploche sa dá priamo otvoriť Nový výdavok alebo Nový príjem (Android; po zmene sa môže vyžadovať znova pridať appku na plochu).
- Skratky fungujú aj offline a po prihlásení sa dokončia (formulár sa otvorí až po prihlásení).

## v2.51.0 – Prihlásenie cez Google

- Flow sa otvára až po prihlásení Google účtom. Prístup majú len účty z hárku FlowUsers v Google Sheets.
- Prihlásenie platí 90 dní a pri používaní sa samo predlžuje. Odhlásiť sa dá v Nastaveniach → Účet.
- Starý zdieľaný kľúč už nie je v kóde stránky. Backend ho prijíma len počas prechodu, kým ho nevypneš funkciou disableLegacyToken.
- Keď prihlásenie vyprší, appka sa vráti na prihlasovaciu obrazovku a neodoslané zmeny ostanú v telefóne.
- Vyžaduje Google Apps Script v2.51.0.

## v2.50.3 – Bezpečnejšie zobrazovanie dát, stabilné knižnice, rýchlejší sync

- Poznámky, kategórie a podkategórie sa zobrazujú ako čistý text. Text z Google Sheets už nemôže spustiť kód v aplikácii (ochrana proti XSS).
- Podkategórie a ID s apostrofom alebo úvodzovkami (napr. O'Neil) sa dajú normálne vybrať, filtrovať a odškrtnúť.
- Knižnice Lucide (1.58.0) a Chart.js (4.5.1) majú pevnú verziu, takže nové vydanie na CDN appku nerozbije. Výpadok CDN už nezhodí offline cache aplikácie.
- Rýchlejšia synchronizácia pri veľkom počte transakcií v aplikácii aj v Google Apps Scripte (nový voliteľný backend v2.50.3; frontend funguje aj so starým v2.49.21).

## v2.50.1 – Kompaktná hlavička, nové karty pravidelných platieb, presnosť odhadu, jeden zdroj verzie

- Hlavička je nižšia a pri scrolle sa ešte zmenší. Nad sumou je napísané, čo číslo znamená (napr. Spolu · Okt 2026, Nové · Okt 2026). Suma používa jednotný formát meny.
- Pravidelné platby: klepnutie na kartu otvorí úpravu, ďalšie akcie (História 12 mes., Pozastaviť, Odstrániť) sú v menu ⋯. Karta ukazuje skutočný dátum ďalšej platby, zoznam je zoradený podľa najbližšej.
- Pozastavené pravidelné platby ostávajú viditeľné v sekcii Pozastavené a dajú sa obnoviť.
- Presnosť odhadu je v ľudskej reči (napr. Odhad sa v priemere líši o 57 %, typicky o 132 € na kategóriu za mesiac). Odborné metriky WAPE, MAE a bias sú v Detaile s jasnejšími názvami.
- Jeden zdroj verzie: assets/js/version.js. Číta ho aplikácia, nastavenia, changelog aj service worker (názov cache). Novú verziu zapíšeš cez python3 tools/bump_version.py <verzia> --note "…".

## v2.49.23 – Ručná úprava plánovaného príjmu

- Ročný plán: plánovaný príjem mesiaca sa dá upraviť klepnutím na políčko príjmu v karte mesiaca alebo cez „Upraviť plánovaný príjem“ v detaile mesiaca.
- Voliteľne sa rovnaká suma použije aj pre všetky nasledujúce neuzavreté mesiace roka. „Vrátiť na odhad modelu“ úpravu zruší.
- Úprava sa prejaví v ročnom výsledku aj v budgete. V aktuálnom mesiaci plán nejde pod už prijatú sumu. Uzavreté mesiace sa neupravujú.
- Ukladá sa ako ručný override s kategóriou `__INCOME__` (už sa synchronizuje do cloudu), preto netreba meniť Google Apps Script. Archív presnosti uchováva pôvodný odhad modelu.

## v2.49.22 – Odstránené tlačidlo Aktualizovať odhad

- Z Ročného plánu zmizla karta „Odhad výdavkov a príjmov“ s tlačidlom `↻ Aktualizovať odhad`.
- Prepočet odhadov beží automaticky na pozadí podľa pôvodných pravidiel (cache sa zneplatní pri každej zmene dát); forecast algoritmus, Budget a Income Engine sa nemenia.

## v2.49.21 – Oprava chýbajúcich pravidelných platieb v novom mesiaci

- **Hlavná príčina:** Google Sheets premieňa dátum začiatku/konca pravidelnej platby na dátumovú bunku a späť ho vracia ako ISO časovú značku (napr. `2026-09-15T22:00:00.000Z`). Pole „Začiatok“ v editore potom ostalo prázdne a generátor transakcií takýto dátum nevedel spracovať, preto sa pravidelné platby nevytvárali.
- Flow teraz dátumy plánov pri načítaní, v editore, v generátore transakcií aj v mesačnom prepočte normalizuje na `YYYY-MM-DD`.
- Pri uložení sa pri prázdnom poli Začiatok zachová pôvodný dátum plánu.
- GAS v2.49.21: dátumy plánov sa čítajú ako text `YYYY-MM-DD` a stĺpce Začiatok/Koniec sa zapisujú ako text. Aplikácia funguje aj bez aktualizácie GAS, no po jej nasadení sa problém neobjaví ani na iných zariadeniach.

- Opravené: pravidelné platby sa v novom mesiaci negenerovali, ak pre rovnaký dátum existoval cloudový tombstone z v2.49.15 (rovnaké `RPOCC_*` ID, vyššia verzia). Server nový záznam odmietol ako konflikt a Flow ho potom lokálne zmazal.
- Pri takomto konflikte sa výskyt pravidelnej platby v aktuálnom mesiaci obnoví s vyššou verziou (iba `RPOCC_*`, aktívny plán, aktuálny mesiac).
- Ručné transakcie a ostatné konflikty sa správajú ako doteraz.
- Zosúladené verzie v `config.js`, `sw.js` a `index.html`.

## v2.49.19 – Ručné prepočítanie odhadu

- V Ročnom pláne pribudlo tlačidlo `↻ Aktualizovať odhad`.
- Ručný prepočet zneplatní aktuálny forecast index a cache výberu modelov a znovu vypočíta aktuálny odhad výdavkov aj príjmov z dostupných dát.
- Počas výpočtu je tlačidlo zablokované a Flow zobrazí okamžitý feedback; po dokončení ukáže úspešné prepočítanie alebo chybu.
- Ročný plán zobrazuje čas posledného prepočtu odhadu.
- Samotný forecast algoritmus, Income Engine, Budget výpočty, recurring logika, synchronizácia a GAS sa nemenia.

## v2.49.18 – Editácia a mazanie udalostí

- V detaile udalosti pribudli akcie `Upraviť` a `Odstrániť`.
- Editovať možno názov, sumu, typ, dátum, kategóriu a poznámku.
- Ak bola udalosť `Splnená` a zmení sa údaj dôležitý pre párovanie (dátum, názov, typ, suma alebo kategória), Flow zruší staré prepojenie a vráti udalosť na `Čaká`.
- Zmena iba poznámky existujúce platné prepojenie neruší.
- Mazanie má samostatné potvrdenie a jasne vysvetľuje, že reálna transakcia sa nemaže.
- Pri mazaní sa lokálne ponechá tombstone, aby staršia cloudová verzia nemohla udalosť po refreshi vrátiť.
- Pri dočasnom zlyhaní cloudu Flow editáciu/mazanie zachová lokálne a pri ďalšom načítaní skúsi cloud opraviť.
- Každá akcia dá používateľovi okamžitý feedback.
- GAS zostáva v2.49.10 z v2.49.17.
- Recurring, Budget a Income Engine sa nemenia.

## v2.49.17 – Stav plánovaných udalostí a spätná väzba

- Udalosti majú stav `Čaká` / `Splnená`.
- Flow hľadá kandidátov medzi reálnymi transakciami podľa typu, sumy, dátumu, názvu/poznámky a kategórie.
- Silná zhoda sa v mesiaci zvýrazní ako `Skontrolovať zhodu`.
- Používateľ musí zhodu potvrdiť; automatické uzavretie sa nerobí.
- Po potvrdení sa uloží `status=completed`, `matchedTransactionId` a `completedAt`.
- Splnená udalosť sa vyradí z `eventIncome` / `eventExpense`, preto sa už druhýkrát nepočíta medzi očakávané peniaze.
- Stav sa dá vrátiť späť na `Čaká`.
- Ukladanie udalosti aj zmeny stavu dáva okamžitý feedback.
- GAS v2.49.10 rozširuje `FlowPlannedEvents` o tri nové polia.
- Recurring logika, Budget override a Income Engine ostávajú bez iných zmien.

## v2.49.16 – Ručný budget zostáva po refreshi

- Opravené načítanie `FlowBudgetOverrides`: cloud už slepo neprepíše novšiu lokálnu ručnú hodnotu.
- Override sa deduplikuje podľa skutočného kľúča `mesiac + kategória`.
- Pri konflikte vyhrá vyššia `version`, následne novší `updatedAt`.
- Ak bol ručný budget uložený lokálne, ale cloudový zápis zlyhal alebo zaostal, Flow ho po ďalšom načítaní automaticky skúsi dopísať do Google Sheets.
- Ručná hodnota má naďalej prednosť pred modelovým budgetom vo výpočte Ročného plánu.
- Pridaná jasná spätná väzba pri ukladaní manuálneho budgetu.
- Forecast algoritmus, Income Engine, recurring logika a Annual Plan výpočtový model sa nemenia.
- Google Apps Script zostáva v2.49.9.

## v2.49.15 – Pravidelné platby iba pre aktuálny mesiac

- Automatické recurring transakcie sa už negenerujú 12 mesiacov dopredu.
- Flow materializuje iba výskyty, ktoré patria do aktuálneho kalendárneho mesiaca.
- Na začiatku nového mesiaca sa nové výskyty vytvoria pri prvom otvorení/synchronizácii aplikácie v danom mesiaci.
- V aktuálnom mesiaci sa vytvoria aj platby s dátumom neskôr v tom istom mesiaci.
- Pri prechode na v2.49.15 sa automaticky označia na zmazanie iba budúce generator-shaped transakcie (`RPOCC_*` / `tx_*`) s `recurringPlanId`.
- Ručné `ID-*` transakcie, aktuálny mesiac a história zostávajú nedotknuté.
- Recurring plán zostáva zdrojom pre budúce mesiace a forecast; mení sa iba materializácia do zoznamu Transakcií.
- Google Apps Script sa nemení; zostáva v2.49.9.
- Annual Plan, Income Engine a forecast algoritmus sa nemenia.

## v2.49.14 – Prepojenie historických pravidelných platieb

- Pri vytvorení novej pravidelnej výdavkovej položky Flow prehľadá posledných 12 mesiacov.
- Hľadanie používa rovnaký typ, kategóriu a podkategóriu; pravdepodobné zhody označí podľa podobnej sumy, názvu a dňa.
- Používateľ vždy rozhoduje checkboxmi, ktoré transakcie naozaj patria k plánu.
- Na každej pravidelnej položke pribudlo tlačidlo `História 12 mes.` pre neskoršie úpravy.
- Vybrané ručné transakcie dostanú `isRecurring=true`, `frequency` a `recurringPlanId`.
- Dátum, suma, poznámka a ID historickej transakcie zostávajú bez zmeny.
- Označenie sa synchronizuje do Sheet1 cez existujúci transaction sync.
- Takto označené výdavky už forecast nepovažuje za variabilné; budúci pravidelný plán sa teda nepripočíta k rovnakému historickému základu druhýkrát.
- V tomto release sa nemení samotný forecast algoritmus, Income Engine ani Annual Plan výpočty.
- Google Apps Script sa oproti v2.49.13 nemení; zostáva v2.49.9.

## v2.49.13 – Oprava už existujúcich pravidelných transakcií

- V Nastaveniach pribudlo `Opraviť existujúce pravidelné platby`.
- Audit hľadá legacy automatické `tx_*` položky a transakcie už prepojené cez `recurringPlanId`.
- Pred každou opravou je povinná kompletná cloudová záloha.
- Opraví `isRecurring`, `frequency` a `recurringPlanId`.
- Pre rovnaký plán a dátum ponechá jednu generator-shaped transakciu a ostatné odstráni.
- Bežné ručne vytvorené `ID-*` transakcie sa automaticky nemažú.
- Po oprave frontend odstráni zmazané ID aj lokálne a urobí cloud pull.
- Ročný plán, Budget, Forecast a Income Engine zostávajú bez zmeny.

## v2.49.12 – Pravidelné platby bez duplicít

- Sheet1 dostal polia `isRecurring`, `frequency`, `recurringPlanId`; metadata už po cloud pull synchronizácii nezmiznú.
- Generované pravidelné transakcie používajú stabilné ID podľa plánu a dátumu.
- Legacy `tx_*` položky sa pri spracovaní bezpečne priradia k správnemu plánu.
- Ak pre rovnaký plán/dátum existuje viac generator-shaped transakcií, Flow ponechá jednu a ostatné pošle ako delete.
- Editácia sumy/frekvencie/kategórie upravuje existujúce generované transakcie podľa zvoleného rozsahu.
- Pridanie a editácia plánu používajú optimistické UI a okamžitý feedback.
- Ročný plán `getAnnualPlan(year)` zostáva nezmenený oproti v2.49.11.

## v2.49.11 – Príjmy aktuálneho mesiaca

- Na stabilný Ročný plán z v2.49.2 bola pridaná iba UI karta príjmov pre aktuálny mesiac.
- Zobrazuje reálne prijaté príjmy, očakávaný príjem, zostávajúcu očakávanú sumu a percentuálny progress.
- Použitá je už predtým funkčná implementácia z v2.49.3.
- `getAnnualPlan(year)` zostáva byte-identický s v2.49.10/v2.49.2.
- Sync, HIST ochrana, GAS, Budget a Forecast sa nemenia.

## v2.49.10 – Ročný plán obnovený zo stabilnej v2.49.2

- `assets/js/planning.js` je byte-for-byte identický s poslednou verziou v2.49.2, kde používateľ potvrdil funkčný Ročný plán.
- Tým sa odstraňujú všetky regresie v Ročnom pláne zavedené po v2.49.2.
- Zachovaná zostáva oprava synchronizácie z v2.49.7.
- Zachovaná zostáva ochrana `FlowHistoricalTombstones` proti opätovnému vytváraniu historických duplicít.
- Google Apps Script zostáva v2.49.7.
- Budget, transakcie, kategórie, analytika a cockpit zostávajú bez zmeny.

## v2.49.7 – Oprava synchronizácie po HIST ochrane

- Opravená regresia v GAS v2.49.6: backend volal `readHistoricalTombstoneSet_()` a `addHistoricalTombstones_()`, ale ich definície v distribuovanom GAS súbore chýbali.
- Táto chyba spôsobila pád `batchSync` ešte pred uložením novej transakcie.
- Doplnené všetky tombstone helper funkcie.
- Bežné `ID-*` transakcie tombstone hárok vôbec nečítajú.
- `FlowHistoricalTombstones` sa používa iba pri `HIST-*` záznamoch.
- Ochrana proti návratu historických duplicít zostáva zachovaná.
- Budget, Forecast, Income Engine a Ročný plán sú bez zmeny.

## v2.49.6 – HIST duplicity sa po čistení už nevrátia

- Opravená príčina opätovného vytvárania historických duplicít po serverovom čistení.
- Backend pri čistení vráti presné `removedIds`.
- Klient odstráni rovnaké ID z lokálnej `db` aj zo `syncQueue` ešte pred následným pullom.
- Lokálne sa uchová tombstone zoznam vyčistených HIST ID, takže pull ich nereinterpretuje ako nové lokálne dáta.
- Backend vytvára `FlowHistoricalTombstones` a odmietne znovu uložiť už vyčistené HIST ID, aj zo starého zariadenia.
- Bežné ID-* transakcie nie sú týmto mechanizmom dotknuté.
- Budget, Forecast, Income Engine a Ročný plán zostávajú bez zmeny.

## v2.49.5 – Bezpečný cloud pre čistenie duplicít

- `data_health` už nevolá `ScriptApp.getProjectTriggers()`, takže bežná kontrola dát nepotrebuje trigger scope.
- Stav auto-zálohy sa pri kontrole číta z Script Properties.
- Čistenie je zablokované, ak existujú lokálne položky čakajúce na synchronizáciu.
- Frontend sa pred čistením pokúsi sync dokončiť a následne overí cloud.
- Backend odmietne čistenie pri čakajúcej sync fronte alebo ak sa počet duplicít zmenil od auditu.
- Po vytvorení povinnej zálohy sa audit zopakuje; pri zmene dát sa nič nemaže.
- Budget, Forecast, Income Engine, Ročný plán a samotné historické dedup pravidlá sa nemenia.

## v2.49.4 – Bezpečné čistenie historických duplicít

- Nastavenia → Ochrana dát ukáže počet historických duplicitných riadkov v `Sheet1`.
- Nové tlačidlo „Vyčistiť historické duplicity“ najprv spraví audit a zobrazí počet nálezov.
- Pred akýmkoľvek mazaním sa povinne vytvorí kompletná cloudová záloha. Ak záloha zlyhá, `Sheet1` sa nemení.
- Čistenie je úmyselne úzke: iba `HIST-*` záznamy s rovnakým dátumom, normalizovanou kategóriou, podkategóriou, sumou, typom a poznámkou.
- Z každej duplicitnej skupiny sa preferuje riadok s platným `categoryId`; bežné `ID-*` transakcie sa nikdy nemažú.
- Budget, Forecast, Income Engine, Ročný plán a uchovávanie presnosti sa nemenia.

## v2.49.3 – Uchovávanie Presnosti plánu

- Vychádza priamo z používateľom potvrdenej stabilnej v2.49.2.
- Nový cloudový hárok `FlowPlanAccuracy` uchováva jeden nemenný snapshot na mesiac.
- Ukladá sa pôvodný Budget a Forecast; skutočnosť sa vždy počíta z reálnych transakcií daného mesiaca.
- Existujúce historické porovnania sa doplnia z `FlowForecastArchive`.
- `getAnnualPlan(year)` zostáva byte-identický s v2.49.2.
- Income Engine, Budget, Forecast a transakčná synchronizácia zostávajú bez zmeny.

## v2.49.2 – Automatické zálohy

- Záloha v posledný deň mesiaca.
- Maximálne 5 cloudových záloh.
- Najstaršia sa pri ďalšej zálohe prepíše.
- Stav auto zálohy v Nastaveniach.

## v2.49.1 – Backup fix

- Záloha cez Spreadsheet.copy namiesto DriveApp.
- Ľahší read-only cloud health check.
- Presné chybové hlášky zo servera.

## v2.49.0 – Data Protection & Backup

- Opravený prázdny Rozpočet z v2.48.0.
- Centrum ochrany dát a diagnostika.
- Kompletné cloudové kópie Google tabuľky, posledných 30 záloh.
- Safety snapshot pred importom JSON.
- Bez zmeny finančného modelu.

## v2.48.0 – UX konsolidácia

- Menej duplicitných údajov na Prehľade.
- Jasnejšia hierarchia Rozpočtu.
- Zrozumiteľnejšie názvy Rozpočet/Odhad.
- Jednotnejšie filtre Analytiky a Tempa míňania.
- Bez zmeny finančných algoritmov.

## v2.47.0 – Koľko ešte môžem minúť?

- Rezerva do konca mesiaca a suma na deň.
- Jednoduchý stav tempa míňania.
- Rozbaliteľné vysvetlenie výpočtu.
- Bez nového finančného modelu.

## v2.46.0 – Finančný kalendár

- Najbližšie platby a príjmy na 31 dní.
- Súhrn Príde / Odíde / Rozdiel.
- Používa existujúce plány a udalosti.
- Bez zmeny finančných výpočtov.

## v2.45.0 – Čo je dobré vedieť

- Najviac 3 dôležité mesačné informácie.
- Jednoduchšie texty.
- Bez zmeny finančných výpočtov.

## v2.44.6 – Presnosť starších mesiacov

- Flow spätne doplní chýbajúce porovnania pre staršie uzavreté mesiace.
- Pre každý mesiac používa iba dáta dostupné pred jeho začiatkom.
- Nové mesiace naďalej používajú plán reálne uložený počas mesiaca.
- V UI sa používa ľudské označenie `uložené počas mesiaca` alebo `spätne dopočítané`.
- Bez zmeny samotných Budget/Forecast algoritmov.

## v2.44.5 – Closed Month Plan Accuracy

- Presnosť plánu sa zobrazuje priamo v kartách uzavretých mesiacov.
- Aktuálny mesiac automaticky archivuje live Budget/Forecast snapshot.
- Po uzavretí sa Budget a Forecast porovnajú so skutočnými výdavkami z transakcií.
- Ak práve uzavretému mesiacu snapshot chýba, Flow doplní walk-forward porovnanie na pozadí.
- Forecast/Budget algoritmy sa nemenia.

## v2.44.4 – Annual Plan & Analytics UX

### Ročný plán
- Dominantný výsledok je očakávaný ročný zostatok.
- Budget, forecast a príjem sú sekundárne kompaktné metriky.
- Model, backtest a presnosť sú schované pod `Ako vzniká ročný plán`.
- Existujúce mesačné karty, klikateľné mesiace, percentá zhody a detail kategórií zostávajú zachované.

### Analytika
- Jedna dominantná suma + najväčšia kategória.
- Počet transakcií a priemer sú pod `Ďalšie štatistiky`.
- Dynamický nadpis grafu vysvetľuje, na akú otázku graf odpovedá.
- Pôvodné filtre, typ grafu, kategórie/podkategórie a Výdavky/Príjmy/Bilancia zostávajú funkčne nezmenené.

### Bezpečnosť regresie
- Bez zmeny: Budget, transakcie, synchronizácia, kategórie, Cockpit, GAS a forecast výpočty.
- Zmeny v `planning.js` a `analytics.js` sú iba render/UI vrstva.

## v2.44.3 — Budget & Tempo míňania UX
- Budget: dominantný mesačný overview, čerpanie a zostávajúca suma.
- Kategórie: na prvý pohľad iba minuté / budget, percento čerpania, zostáva a stav.
- Forecast, confidence a sekundárne metriky sú pod progressive disclosure.
- Burn Rate je v UI premenovaný na Tempo míňania; technické ovládanie grafu je pod Detail analýzy.
- Existujúce ID filtrov, event handlery a analytické výpočty zostávajú zachované.
- Sync, kategórie, transakcie, Planning, Income Engine a GAS bez zmien.

## v2.44.2 — UI Simplification
- Financial Cockpit má jednu dominantnú metriku: očakávaný zostatok.
- Minuté, Forecast a Safe to Spend sú kompaktné sekundárne metriky.
- Menej používané údaje sú pod natívnym rozbaľovacím `Detail mesiaca` (progressive disclosure).
- Filter panel Transakcií je vizuálne zjednotený bez zmeny jeho logiky alebo event handlerov.
- Farebnosť je obmedzená na stavové informácie; bežné údaje zostávajú neutrálne.
- Budget, Forecast, Planning, sync, kategórie, transakcie, Income Engine a GAS sú bez funkčných zmien.

## v2.44.1 — Safe to Spend 2.0 + Cockpit Placement
- Finančný cockpit je presunutý nad filtre na obrazovke Transakcie, aby nebol vložený medzi filtre a zoznam transakcií.
- Pridaný read-only blok `Safe to Spend`: voľný budget do konca aktuálneho mesiaca, orientačný denný limit a 7-dňový limit.
- Safe to Spend priamo používa existujúcu rezervu `Budget − Forecast`; nepridáva nový finančný model ani nové odpočty.
- Denný a 7-dňový údaj sú iba rozpočítaním tejto existujúcej rezervy na zostávajúci čas mesiaca.
- Safe to Spend je iba prezentačný odvodený údaj; nič nezapisuje a nemení Budget, Forecast, Annual Plan, transakcie, recurring plány ani synchronizáciu.
- Budget modul, Forecast model, Income Engine, kategórie a GAS zostávajú funkčne bez zmien.

## v2.44.0 — Financial Cockpit
- Pridaný read-only Finančný cockpit na obrazovku Transakcie.
- Zobrazuje existujúce metriky: minuté doteraz, forecast mesiaca, rezervu podľa forecastu a očakávaný zostatok.
- Cockpit používa existujúci `getBudgetDataset()` a `buildBudgetInsights()`; nevytvára nový forecast ani nemení výpočty.
- Pri výbere viacerých mesiacov sa mesačné KPI zámerne nezlučujú.
- Budget, Annual Plan, Forecast model, Income Engine, kategórie, synchronizácia a GAS ostávajú funkčne nezmenené.

# Flow – CHANGELOG

## v2.43.5 – Category Data Protection

- Po vymazaní cache/cookies sa kategórie už neinicializujú generickými defaultmi ako autoritatívne dáta.
- Aplikácia pred prvým zápisom po strate lokálneho stavu vždy načíta cloudový baseline.
- Známy generický starter set je na klientovi aj v GAS natrvalo blokovaný pre zápis do Google Sheets.
- Posledná potvrdená sada kategórií je zabudovaná iba ako bezpečný recovery fallback; cloud má pri normálnej prevádzke prioritu.
- Legacy kategórie bez `uid` dostávajú deterministické stabilné ID, takže cache clear nemení väzby `categoryId`.
- GAS v2.43.5 pridáva `categories_meta` s cloudovou verziou a pred každou reálnou zmenou uloží predchádzajúcu konfiguráciu do `CategoriesBackup` (max. 100 snapshotov).
- Pri konflikte sa lokálna verzia už slepo neopakuje; najprv sa znovu načíta serverová verzia.
- Budget modul, forecast model `2.42.0-category-champions-v1` a Income Engine zostávajú bez zmien.

## v2.43.4 – Closed Month Historical Values

- Pri uzavretom mesiaci sú explicitne zobrazené tri hodnoty: `Budget`, `Forecast`, `Skutočné výdavky`.
- Budget zobrazuje aj rezervu alebo prekročenie voči skutočným výdavkom.
- Forecast zobrazuje absolútnu odchýlku od skutočných výdavkov.
- Percentuálna zhoda Budget/Forecast zostáva ako sekundárne vyhodnotenie pod sumami.
- Skutočné výdavky sa naďalej berú zo zapísaných transakcií.
- Budget modul, forecast model, Income Engine a GAS bez zmeny.

## v2.43.3 – Plan vs. Reality

### Uzavreté mesiace
- Skutočné výdavky sa berú priamo zo zapísaných transakcií.
- Pridaná `Budget – zhoda` v % voči skutočným výdavkom.
- Pridaná `Forecast – zhoda` v % voči skutočným výdavkom.
- 100 % znamená presnú zhodu; percento klesá podľa absolútnej odchýlky.
- Preferujú sa reálne uložené snapshoty plánu/forecastu; ak nie sú dostupné, použije sa historický backtest a UI to označí.
- Ak nie je dostupný žiadny dôveryhodný podklad, percento sa nevymýšľa.

### Aktuálny mesiac
- `Z budgetu vyčerpané` = skutočné výdavky doteraz / mesačný budget.
- `Z forecastu dosiahnuté` = skutočné výdavky doteraz / aktuálny forecast výdavkov.
- Zobrazuje sa aj percento uplynutej časti mesiaca ako kontext.
- Hodnoty nad 100 % sú explicitne označené.

### Model / backend
- Budget modul ostáva nezmenený oproti v2.43.2/v2.43.1.
- Forecast model ostáva `2.42.0-category-champions-v1`.
- Income Engine sa nemení.
- Google Apps Script zostáva v2.38.8.

## v2.43.2 – Annual Plan Clarity & Navigation

- Uzavretý mesiac: `Skutočné výdavky`, `Skutočný príjem`, `Konečný zostatok`.
- Aktuálny mesiac: `Mesačný budget`, `Minuté doteraz`, `Forecast výdavkov`, `Očakávaný príjem`, `Očakávaný zostatok`.
- Budúci mesiac: `Mesačný budget`, `Forecast výdavkov`, `Plánovaný príjem`, `Očakávaný zostatok`.
- Odstránená nejasná veľká suma bez popisu.
- 12-mesačný prehľad je klikateľný a naviguje na konkrétny mesiac.
- Každá karta mesiaca má `↑ Prehľad` pre návrat k 12-mesačnému prehľadu.
- Budget modul, forecast model, Income Engine a GAS bez zmeny.

## v2.43.1 – Budget Regression Fix

### Oprava
- `assets/js/budget.js` je obnovený **byte-for-byte z v2.42.6**, teda z poslednej overenej verzie pred UX zásahom v2.43.0.
- Odstránené experimentálne zoradenie Budget kategórií podľa rizika.
- Odstránené experimentálne Budget risk-statusy z v2.43.0.
- Budget forecast, recommended budget, spent, safe-to-spend a kategóriové výpočty sa opäť správajú identicky ako vo v2.42.6.

### Zachované z v2.43.0
- 12-mesačný UX prehľad v Ročnom pláne.
- UI/accessibility zlepšenia, focus stavy a reduced-motion.

### Model / backend
- Forecast model ostáva `2.42.0-category-champions-v1`.
- Income Engine sa nemení.
- Google Apps Script zostáva v2.38.8.

## v2.43.0 – UX System Pass

- Ročný plán: 12-mesačný prehľad zostatkov s rýchlou navigáciou.
- Budget: kategórie zoradené podľa rizika a tempa míňania.
- Stavy: V poriadku / Sleduj / Riziko / Nad plánom.
- Zjednotená semantika farieb, focus stavy a reduced-motion.
- Forecast model, Income Engine a Google Apps Script sa nemenia.

## v2.42.6 – Annual Plan Category Cards

### Ročný plán
- Kategórie v detaile mesiaca používajú nový profesionálny card layout.
- Každá karta má jasnú hierarchiu `Budget → Forecast → Zostáva`.
- Stav kategórie je označený textom `Rezerva`, `Tesne pri limite` alebo `Nad plánom`.
- Tenký progress indikátor ukazuje podiel forecastu voči budgetu.
- Zostatok zostáva semanticky zelený/červený/neutrálny a farba nie je jediným nosičom významu.
- Mobilný a dark-mode layout bol doladený.

### Ostatné
- Zachované existujúce UI Budgetu z v2.42.5.
- Forecast model, Income Engine a Google Apps Script sa nemenia.

## v2.42.5 – Category Balance UX

### Budget
- `Budget`, `Minuté` a `Forecast` zostávajú kompaktné porovnávacie metriky.
- `Zostáva` je samostatný výsledkový pás s vyššou vizuálnou prioritou.
- Plus = `Rezerva v kategórii`, mínus = `Nad plánom`.
- Kladná hodnota používa jemnú zelenú semantiku, záporná červenú, nula neutrálnu.

### Ročný plán
- V detaile mesiaca má každá kategória nový `Zostáva = Budget − Forecast`.
- Na mobile sa výsledok presúva na vlastný riadok.

### UI/UX
- Vstupy a výsledok sú vizuálne oddelené, takže používateľ vie rýchlejšie skenovať kategórie.
- Farba je iba podporný signál; význam ostáva čitateľný z textu a znamienka.
- Rozloženie je optimalizované pre mobilné displeje.

### Model / backend
- Forecast model ostáva `2.42.0-category-champions-v1`.
- Income Engine sa nemení.
- Google Apps Script zostáva v2.38.8.

## v2.42.4 – Balance UI/UX Hierarchy

### Budget
- `Safe to spend` používa zelenú/červenú/neutrálnu semantiku podľa výsledku.
- Karta zobrazuje aj textový stav `V pluse`, `V mínuse` alebo `Na nule`.
- `Zostáva` pri každej kategórii má jemné semantické pozadie, border a farebnú hodnotu.

### Ročný plán
- `Očakávaný zostatok` používa rovnakú semantiku ako Budget.
- Mesačný `Zostatok` je zvýraznený jemným zeleným/červeným/neutrálnym povrchom.

### UI/UX
- Farba nie je jediný nosič informácie.
- Výsledok ostáva dominantný, farebná plocha je iba jemná podpora.
- Light a dark mode majú samostatne nastavený kontrast.
- Použité sú tabular numerals pre stabilnejšie porovnanie finančných hodnôt.

### Model / backend
- Forecast model ostáva `2.42.0-category-champions-v1`.
- Income Engine sa nemení.
- Google Apps Script zostáva v2.38.8.

## v2.42.3 – Signed Result Colors + Changelog

### UI
- Plusové výsledky v Budgete a Ročnom pláne sú zelené.
- Mínusové výsledky sú červené.
- Nulové výsledky zostávajú neutrálne.
- Pravidlo sa používa pre `Safe to spend`, zostávajúci budget, mesačný zostatok a očakávaný ročný zostatok.
- Farby majú samostatný kontrast pre light a dark mode.

### Changelog
- Doplnená chýbajúca položka v2.42.2 aj do changelog modalu v aplikácii.

### Model / backend
- Forecast model sa nemení (`2.42.0-category-champions-v1`).
- Income Engine sa nemení.
- Google Apps Script zostáva v2.38.8.

## v2.42.2 – Dark Mode Contrast Fix

### Fixed
- Ročný plán už v dark mode nepoužíva biele karty s bielym textom.
- Budget a Ročný plán používajú spoločné theme premenné pre povrch, text a border.
- Dynamicky renderované mesačné karty, hero karty, mini-karty a tlačidlá majú v dark mode vynútený správny kontrast.
- Pridaný cache-busting pre `styles.css`, aby mobil/PWA nezostal na starom CSS po aktualizácii.
- Forecast ani Income Engine sa nemenia.

## v2.42.1 – Dark Mode Readability

### Fixed
- Kompletná čitateľnosť tabu **Budget** v dark mode.
- Tmavé povrchy, texty, štatistiky, forecast riadky, insighty a vysvetlenie výpočtu používajú kontrastné dark-mode farby.
- Kompletná čitateľnosť tabu **Ročný plán** v dark mode.
- Opravené hero karty, mesačné karty, mini štatistiky, plánovacie udalosti, tlačidlá a výber roku.
- Dark mode funguje pri systémovom `prefers-color-scheme: dark` aj pri explicitnej `.dark` triede.

### Unchanged
- Forecast model zostáva **2.42.0-category-champions-v1** – nový backtest nie je potrebný.
- Income Engine zostáva bez zmeny.
- Google Apps Script zostáva v2.38.8.

---

## v2.42.0 – Category Champions

### Forecast / model selection
- Výdavkový selector už nevyberá championa samostatne pre každý kalendárny mesiac.
- Každá kategória má stabilného category championa odvodeného z doterajších walk-forward scenárov.
- Challenger môže category prior nahradiť iba pri jasnom zlepšení: 8 % pri menšej vzorke, 5 % pri 36+ validačných obdobiach.
- Do kandidátov sa vrátil `multi-year-trend`, založený na overenom multi-year level + seasonality + trend modeli z v2.38.2.
- Odstránené je mesačné prepínanie modelov, ktoré mohlo pri riedkych kategóriách viesť k preučeniu.
- Champion cache/model state je teraz viazaný na kategóriu, nie na kategóriu + mesiac.

### Scenario archive
- Priory pre kategórie boli nastavené podľa doterajších archivovaných walk-forward experimentov.
- Stabilné a dobre podložené výsledky majú prednosť pred malou vzorkou s náhodne nízkou chybou.
- Kategórie s nedostatkom dát používajú konzervatívny adaptívny fallback.

### Income Intelligence
- **Bez zmeny oproti v2.41.0.**
- Income WAPE / MAE / Bias / Accuracy zostávajú zachované.
- Pravidelný príjem má naďalej prednosť pred historickým forecastom rovnakého zdroja.

### Google Apps Script
- **Bez zmeny backendu.** Zostáva Google Apps Script v2.38.8.

### Unchanged
- Pravidelné platby sa generujú maximálne 12 mesiacov dopredu.
- Forecast Archive zostáva cloud-first.
- Rýchly filter kategórií/podkategórií zostáva iba v Transakciách.
- Filtre rokov v Grafoch a Burn Rate zostávajú zachované.
- Existujúci sync indikátor/UI sa nemení.

---

## v2.41.0 – Meta Forecast + Income Intelligence

### Forecast / model selection
- Champion výber teraz zohľadňuje nielen kategóriu, ale aj **kalendárny mesiac**.
- Mesačný výkon kandidátov sa aktivuje až po minimálne 2 historických pozorovaniach a je tlmený smerom ku kategóriovému skóre (`n / (n + 8)`), aby sa model nepreučil na malej vzorke.
- Live výber používa jeden online validačný stav na kategóriu a dátový cutoff; všetkých 12 mesiacov z neho číta lacno bez opakovaného kompletného backtestu.
- Model state je viazaný na verziu forecast modelu, takže staré champion výsledky sa po upgrade nepoužijú omylom.

### Income Intelligence
- Pôvodný príjmový forecast (jednoduchý priemer posledných kladných mesiacov) bol nahradený modelom podľa **zdrojov/podkategórií príjmu**.
- Stabilné príjmy používajú robustný recent level, obmedzený trend a jemný same-month sezónny signál.
- Variabilné a riedke príjmy používajú pravdepodobnosť výskytu a typickú sumu; pri nízkej pravdepodobnosti sa nepredikujú ako istý príjem.
- Nulové mesiace sa už pri nepravidelných príjmoch neignorujú.
- Pravidelný príjem z plánu nahrádza historický forecast rovnakého zdroja, čím sa odstraňuje možné dvojité započítanie výplaty.
- Pri aktuálnom mesiaci Flow zohľadní už evidovaný príjem a predikuje iba zostávajúcu časť.

### Recurring
- Tab Pravidelné podporuje aj **pravidelný príjem** (napr. výplata).
- Pravidelná položka má typ Výdavok / Príjem a podkategóriu/zdroj.
- Automatické transakcie zostávajú striktne limitované na maximálne **12 mesiacov dopredu**.

### Backtest / diagnostics
- Walk-forward backtest od tejto verzie archivuje aj samostatný mesačný záznam `__INCOME__`.
- Diagnostika zobrazuje **Income WAPE, Income MAE, Income Bias a orientačnú accuracy** oddelene od výdavkov.
- Live snapshoty príjmu sa ukladajú do Forecast Archive, ale neovplyvňujú walk-forward metriky.

### Experiment data
- Pri návrhu meta výberu boli použité doterajšie archivované forecast scenáre. Na priamo porovnateľných historických záznamoch bolo vidieť, že žiadna jedna modelová verzia nie je najlepšia pre všetky kategórie a mesiace.
- Experimentálny selector kategória + kalendárny mesiac znižoval historické WAPE oproti najlepšiemu samostatnému modelu; preto sa tento signál pridáva konzervatívne a so shrinkage.

### Google Apps Script
- **Bez zmeny backendu.** Zostáva Google Apps Script v2.38.8.

### Unchanged
- Forecast Archive zostáva cloud-first.
- Rýchly filter kategórií/podkategórií zostáva iba v Transakciách.
- Filtre rokov v Grafoch a Burn Rate zostávajú zachované.
- Existujúci sync indikátor/UI sa nemení.

---

## v2.40.0 – Champion / Challenger Forecast

### Added
- Forecast pre každú kategóriu automaticky testuje viac kandidátnych modelov na historických dátach.
- Kandidáti: pôvodný adaptívny model, recent robust, rovnaký mesiac, sezónne okno ±1 mesiac, minulý rok, sezónny index, kalendár udalostí a nulový baseline.
- Champion sa vyberá samostatne pre každú kategóriu pomocou walk-forward validácie bez použitia budúcich dát.
- Do Forecast Archive sa ukladajú aj informácie o zvolenom championovi, validačnom WAPE, Budget WAPE a zlepšení oproti baseline.
- Diagnostika zobrazuje presnosť podľa konkrétne zvoleného champion modelu.

### Safety / Model governance
- Challenger musí zlepšiť validačné skóre aspoň o **3 %**, inak zostáva pôvodný adaptívny model.
- Nulový baseline sa nepoužije iba preto, že kategória je riedka; ak nie je materiálne lepší, prednosť dostane zmysluplný nenulový model.
- Výber modelu používa maximálne posledných 24 validačných období a minimálne 12 mesiacov tréningovej histórie.
- Model sa vyberá iba z údajov dostupných pred predpovedaným obdobím.

### Performance
- Champion výber sa cacheuje podľa kategórie a dátového cutoffu.
- Pri zmene transakcií sa cache automaticky invaliduje.
- Historický backtest používa lineárny online champion výber namiesto opakovaného prepočítania celej validačnej histórie.
- Historický backtest priebežne uvoľňuje event loop, aby mobilné UI počas výpočtu nezamrzlo.
- Ročný plán už neprepočítava forecast pre uzavreté mesiace; používa skutočné Actual hodnoty a model počíta iba aktuálny/budúci horizont.

### Model
- Nová verzia modelu: `2.40.0-champion-challenger-v1`.
- Výsledky sa archivujú oddelene od v2.39.0, takže sa dajú priamo porovnať.

### Google Apps Script
- **Bez zmeny backendu.** Zostáva Google Apps Script v2.38.8.

### Unchanged
- Cloud-first Forecast Archive zostáva zachovaný.
- Pravidelné platby sa stále generujú maximálne 12 mesiacov dopredu.
- Rýchly filter kategórií/podkategórií zostáva iba v Transakciách.
- Filtre rokov v Grafoch a Burn Rate zostávajú zachované.

---

## v2.39.0 – Category-Adaptive Forecast

### Added
- Automatická klasifikácia kategórií na **stabilné/husté**, **variabilné**, **riedko sezónne** a **nepravidelné/intervalové**.
- Riedko sezónny model používa pravdepodobnosť výdavku v konkrétnom období a typickú sumu udalosti.
- Nepravidelný model využíva typickú medzeru medzi udalosťami (hazard/intermittent princíp) a kalendárnu pravdepodobnosť.
- Forecast už pri riedkych kategóriách nerozlieva veľký jednorazový alebo ročný výdavok rovnomerne do všetkých mesiacov.
- Budget pri neistých udalostiach používa pravdepodobnostnú rezervu, zatiaľ čo forecast sa snaží vyjadriť najpravdepodobnejší mesačný scenár.
- Diagnostika presnosti podľa použitého forecast modelu.
- Priamo v diagnostike je vysvetlenie WAPE, MAE a Bias.

### Improved
- Sezónny model toleruje posun udalosti približne o jeden mesiac medzi rokmi.
- Novšie historické udalosti majú vyššiu váhu pri odhade typickej sumy.
- Trend sumy udalosti je obmedzený, aby jeden extrémny rok nespôsobil prudký skok forecastu.
- Roky s menej než 24 backtestov sú v diagnostike označené ako **málo dát**.

### Analytics / Backtest
- Nová verzia modelu: `2.39.0-category-adaptive-v1`.
- Backtest sa archivuje oddelene od starších modelov, takže je možné objektívne porovnať výsledok s v2.38.8.
- Do diagnostických vstupov sa ukladajú aj typ modelu, pravdepodobnosť udalosti, aktivita kategórie, koncentrácia sezónnosti a typická medzera medzi udalosťami.

### Google Apps Script
- **Bez zmeny backendu.** Používa sa existujúci Google Apps Script v2.38.8.

### Unchanged
- Cloud-first Forecast Archive zostáva zachovaný.
- Pravidelné platby sa stále generujú maximálne 12 mesiacov dopredu.
- Rýchly filter kategórií/podkategórií zostáva iba v Transakciách.
- Filtre rokov v Grafoch a Burn Rate zostávajú zachované.

---

## v2.38.8 – Cloud-first Forecast Archive

### Fixed
- Opravené zlyhanie `QuotaExceededError` pri spustení „Vyhodnotiť históriu“.
- Celý forecast archív sa už neukladá do `localStorage`; zdrojom pravdy je Google Sheets.
- Pri štarte sa odstráni starý veľký lokálny kľúč `flow_forecast_archive_v235`, čím sa uvoľní miesto v prehliadači.
- Načítanie planning dát sťahuje iba archív aktuálnej verzie forecast modelu, nie všetky historické modely.

### Performance
- Menší objem dát v localStorage.
- Menší planning payload z Google Apps Script pri viacerých verziách modelu.
- Backtest zostáva dávkovaný po blokoch a po uložení funguje diagnostika z dát načítaných v pamäti.

### Google Apps Script
- **Vyžaduje aktualizáciu backendu** na `Flowapp-Google-Apps-Script-v2.38.8.gs`.

---

## v2.38.7 – Backtest Repair & Reliable Archive Sync

### Fixed
- Opravené vyhodnotenie histórie po prechode na model 2.38.6.
- Backend teraz ukladá príznak `backtest: walk-forward`, takže sa historické výsledky po opätovnom načítaní nestratia z metrík.
- Staré neúplné archívne riadky už neblokujú vytvorenie nového korektného backtestu.
- Vyhodnotenie histórie zobrazuje priebeh a chybu namiesto tichého zlyhania.
- Historické predikcie sa do Google Sheets odosielajú v dávkach po 100 riadkoch.

### Google Apps Script
- **Vyžaduje aktualizáciu backendu** na `Flowapp-Google-Apps-Script-v2.38.7.gs`.
- `FlowForecastArchive` dostáva doplnkové stĺpce pre backtest a sezónnu diagnostiku. Existujúce dáta zostávajú zachované.

### Unchanged
- Adaptive seasonal forecast z v2.38.6 zostáva zachovaný.
- Limit pravidelných platieb maximálne 12 mesiacov dopredu zostáva nezmenený.

## v2.38.6 – Adaptive Seasonal Forecast

### Added
- Adaptívny sezónny forecast pre silne sezónne kategórie.
- Pri kategóriách, ktoré sa opakujú v rovnakom mesiaci naprieč rokmi, model kombinuje celkový trend so skutočnými hodnotami rovnakého mesiaca.
- Meranie `seasonalOccurrence`, `seasonalStrength` a priameho historického sezónneho odhadu.
- Aktuálny changelog priamo v aplikácii cez ikonu ⓘ vpravo hore.

### Improved
- Silná sezónnosť dostáva vyššiu váhu iba vtedy, keď sa opakuje vo viacerých rokoch.
- Jednorazový výkyv v jednom roku má menšiu šancu skresliť budúci forecast.
- Riedke sezónne kategórie sa menej „rozlievajú“ do mesiacov, v ktorých sa historicky takmer nevyskytovali.

### Unchanged
- Google Apps Script sa v tejto verzii nemení.
- 12-mesačný limit generovania pravidelných platieb zostáva zachovaný.
- UI Ročného plánu a diagnostiky zostáva zachované.

---

## v2.38.5 – Forecast Diagnostics & Annual Plan Mobile Fix

### Added
- Detailná diagnostika presnosti forecastu priamo z Ročného plánu.
- Vyhodnotenie presnosti podľa kategórie, mesiaca, roku a typu výdavkov.
- Zobrazenie WAPE, Budget WAPE, MAE a biasu v diagnostike.
- Rebríček kategórií s najväčším priestorom na zlepšenie aj najpresnejších kategórií.
- Klik na riadok metrík otvorí detail diagnostiky.
- Po „Vyhodnotiť históriu“ sa po dokončení automaticky otvorí diagnostika.

### Fixed
- Metriky presnosti už používajú iba unikátne walk-forward backtesty.
- Priebežné live snapshoty sa už nezapočítavajú do WAPE, takže jeden mesiac nemôže dostať vyššiu váhu len preto, že bol archivovaný viackrát.
- „Vyhodnotiť históriu“ funguje aj vtedy, keď už netreba doplniť nové historické riadky – obnoví vyhodnotenie a zobrazí diagnostiku.
- Horné karty Ročného plánu sa na mobile zobrazujú 2 × 2; štvorstĺpcové rozloženie sa zapína až od šírky 900 px.
- Čísla v horných kartách majú bezpečnejšie responzívne rozmery a neprekrývajú susedné karty.

### Performance
- Diagnostika sa počíta až po otvorení detailu; nezvyšuje náklady bežného vykreslenia Ročného plánu.
- Základné metriky používajú deduplikovaný backtestový dataset.

### Unchanged
- Forecast matematika modelu `2.38.2-multi-year-walkforward` sa v tejto verzii nemení. Najprv meriame, ktoré kategórie a obdobia spôsobujú chybu.
- Google Apps Script netreba kvôli v2.38.5 meniť.
- Pravidelné platby zostávajú limitované na maximálne 12 mesiacov dopredu.
- Rýchly filter kategórií/podkategórií zostáva iba v Transakciách.
- Filtre rokov v Grafoch a Burn Rate zostávajú zachované.

---

## v2.38.4 – Year Filters
- Pridaný samostatný filter roku pre Grafy a Burn Rate.
- Roky sa generujú dynamicky z databázy + aktuálny rok a minimálne jeden rok dopredu.
- Grafy a Burn Rate už nie sú závislé od roku zvoleného v Transakciách.

## v2.38.3 – Category & Subcategory Filters
- Rýchly filter kategórií/podkategórií je iba v Transakciách.
- Opravené prepínanie kategórie a podkategórie a ich spoločné filtrovanie.

## v2.38.2 – Multi-year Forecast & Backtest
- Multi-year forecast, dynamické historické roky a walk-forward backtest.
- Optimalizovaný index transakcií.
- Forecast archív a historické metriky.
- Pravidelné platby maximálne 12 mesiacov dopredu.
