# Flow v2.49.20 – Dark mode patch

This patch fixes the dark-mode readability problem across the Flow modules.

Main findings:
- `--surface` was used by newer modules but was not defined.
- Several modules still contained hard-coded light card backgrounds.
- Dark-mode overrides were incomplete for some dynamically rendered cards and secondary panels.

The patch is intentionally limited to visual/theme CSS. It does not modify:
- forecast calculations,
- Budget/Annual Plan calculation logic,
- recurring-payment logic,
- Google Apps Script,
- transaction data,
- synchronization logic.

## Apply

Append `dark-mode-fix.css` to the end of:

`assets/css/styles.css`

Then bump the CSS cache-busting version in `index.html`.

Recommended release label: `v2.49.20`.

A full deploy ZIP could not be reconstructed safely from the currently accessible repository source in this session. Do not deploy this patch as a standalone Flow application ZIP; it is a CSS patch only.
